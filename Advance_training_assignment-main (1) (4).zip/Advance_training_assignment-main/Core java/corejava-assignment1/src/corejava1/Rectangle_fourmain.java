package corejava1;



public class Rectangle_fourmain {

	public static void main(String[] args) {
		
		Rectangle_four  obj = new Rectangle_four();
		Rectangle_four obj1 = new Rectangle_four(4, 4);
		obj.printData();
		obj.printArea();
		obj.printPerimeter();


		obj1.printData();
		obj1.printArea();
		obj1.printPerimeter();
		;

	}

}
