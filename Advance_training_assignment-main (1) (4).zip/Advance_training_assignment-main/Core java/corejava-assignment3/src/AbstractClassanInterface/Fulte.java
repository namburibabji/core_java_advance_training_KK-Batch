package AbstractClassanInterface;

public abstract class Fulte extends Instrument {
	@Override
	public void play() {
		System.out.println("Flute is playing  toot toot toot toot");

	}
}
